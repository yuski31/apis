export interface NavItem {
  title: string;
  href: string;
  disabled?: boolean;
  external?: boolean;
}

export interface NavItemGroup {
  title: string;
  items: NavItem[];
}

export const docsConfig: NavItemGroup[] = [
  {
    title: "Getting Started",
    items: [
      {
        title: "Introduction",
        href: "/docs",
      },
      {
        title: "Quick Start",
        href: "/docs/quick-start",
      },
      {
        title: "Authentication",
        href: "/docs/authentication",
      },
    ],
  },
  {
    title: "Core Concepts",
    items: [
      {
        title: "Rate Limits",
        href: "/docs/core-concepts/rate-limits",
      },
      {
        title: "Errors",
        href: "/docs/core-concepts/errors",
      },
      {
        title: "Pagination",
        href: "/docs/core-concepts/pagination",
      },
      {
        title: "Webhooks",
        href: "/docs/core-concepts/webhooks",
      },
      {
        title: "Streaming",
        href: "/docs/core-concepts/streaming",
      },
    ],
  },
  {
    title: "API Reference",
    items: [
      {
        title: "Text Generation",
        href: "/docs/api/text-generation",
      },
      {
        title: "Embeddings",
        href: "/docs/api/embeddings",
      },
      {
        title: "Vision",
        href: "/docs/api/vision",
      },
    ],
  },
];