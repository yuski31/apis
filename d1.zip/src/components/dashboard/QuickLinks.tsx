import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Book, CreditCard, LifeBuoy } from "lucide-react"
import { Link } from "react-router-dom"

export const QuickLinks = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Links</CardTitle>
      </CardHeader>
      <CardContent className="grid gap-4">
        <Button variant="outline" className="justify-start" asChild>
          <Link to="/docs">
            <Book className="mr-2 h-4 w-4" />
            Read the Docs
          </Link>
        </Button>
        <Button variant="outline" className="justify-start" asChild>
          <Link to="/pricing">
            <CreditCard className="mr-2 h-4 w-4" />
            Manage Billing
          </Link>
        </Button>
        <Button variant="outline" className="justify-start" asChild>
          <Link to="/contact">
            <LifeBuoy className="mr-2 h-4 w-4" />
            Contact Support
          </Link>
        </Button>
      </CardContent>
    </Card>
  )
}