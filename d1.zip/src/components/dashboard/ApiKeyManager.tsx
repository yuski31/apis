"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Copy, Check } from "lucide-react"
import { showSuccess } from "@/utils/toast"

const initialKeys = [
  { id: 1, key: "shin_sk_test_1a2b3c4d5e6f7g8h9i0j", created: "2024-07-15" },
  { id: 2, key: "shin_sk_test_k1l2m3n4o5p6q7r8s9t0", created: "2024-06-28" },
]

export const ApiKeyManager = () => {
  const [keys, setKeys] = useState(initialKeys)
  const [copiedKey, setCopiedKey] = useState<number | null>(null)

  const handleCopy = (key: string, id: number) => {
    navigator.clipboard.writeText(key)
    setCopiedKey(id)
    showSuccess("API Key copied to clipboard!")
    setTimeout(() => setCopiedKey(null), 2000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>API Keys</CardTitle>
        <CardDescription>Manage your secret API keys for accessing the Shin AI platform.</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Key (truncated)</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {keys.map((apiKey) => (
              <TableRow key={apiKey.id}>
                <TableCell className="font-mono">shin_sk_...{apiKey.key.slice(-4)}</TableCell>
                <TableCell>{apiKey.created}</TableCell>
                <TableCell className="text-right">
                  <Button size="icon" variant="ghost" onClick={() => handleCopy(apiKey.key, apiKey.id)}>
                    {copiedKey === apiKey.id ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <Button className="mt-4">Generate New Key</Button>
      </CardContent>
    </Card>
  )
}