"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Area, AreaChart, CartesianGrid, XAxis } from "recharts"

const chartData = [
  { date: "2024-07-01", calls: 222 },
  { date: "2024-07-02", calls: 180 },
  { date: "2024-07-03", calls: 350 },
  { date: "2024-07-04", calls: 300 },
  { date: "2024-07-05", calls: 480 },
  { date: "2024-07-06", calls: 450 },
  { date: "2024-07-07", calls: 600 },
]

const chartConfig = {
  calls: {
    label: "API Calls",
    color: "hsl(var(--primary))",
  },
}

export const UsageChart = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>API Usage</CardTitle>
        <CardDescription>Your API call volume for the last 7 days.</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[200px] w-full">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="colorCalls" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--color-calls)" stopOpacity={0.8} />
                <stop offset="95%" stopColor="var(--color-calls)" stopOpacity={0.1} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey="date"
              tickLine={false}
              axisLine={false}
              tickMargin={8}
              tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            />
            <ChartTooltip cursor={false} content={<ChartTooltipContent />} />
            <Area
              dataKey="calls"
              type="natural"
              fill="url(#colorCalls)"
              stroke="var(--color-calls)"
              stackId="a"
            />
          </AreaChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}