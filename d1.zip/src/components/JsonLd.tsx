import { Helmet } from 'react-helmet-async';

const APP_URL = import.meta.env.VITE_APP_URL || 'https://shin.example';

export const JsonLd = () => {
  const organizationSchema = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    'name': 'Shin AI',
    'url': APP_URL,
    'logo': `${APP_URL}/favicon.ico`,
    'sameAs': [
      'https://twitter.com/shin_example',
      'https://github.com/shin-example',
      'https://www.linkedin.com/company/shin-example'
    ]
  };

  const websiteSchema = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    'url': APP_URL,
    'name': 'Shin AI',
    'description': 'Reliable, scalable AI APIs for text, embeddings, vision, and speech—simple pricing, great docs, and transparent limits.',
    'publisher': {
      '@type': 'Organization',
      'name': 'Shin AI',
      'logo': {
        '@type': 'ImageObject',
        'url': `${APP_URL}/favicon.ico`
      }
    }
  };

  return (
    <Helmet>
      <script type="application/ld+json">
        {JSON.stringify(organizationSchema)}
      </script>
      <script type="application/ld+json">
        {JSON.stringify(websiteSchema)}
      </script>
    </Helmet>
  );
};