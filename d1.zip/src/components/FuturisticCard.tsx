import { cn } from "@/lib/utils";
import { Card, CardHeader, CardContent, CardFooter, CardTitle, CardDescription } from "@/components/ui/card";
import { motion, HTMLMotionProps } from "framer-motion";

interface FuturisticCardProps extends HTMLMotionProps<"div"> {
  children: React.ReactNode;
  glow?: boolean;
}

const FuturisticCard = ({ children, className, glow = true, ...props }: FuturisticCardProps) => {
  return (
    <motion.div
      whileHover={{ scale: 1.03, y: -5 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className={cn(
        "relative rounded-lg p-[1px] transition-all duration-300 h-full",
        "bg-gradient-to-br from-border/50 via-border/20 to-border/50",
        glow && "hover:bg-gradient-to-br hover:from-primary hover:via-secondary hover:to-primary hover:shadow-2xl hover:shadow-primary/20",
        className
      )}
      {...props}
    >
      <Card className="h-full w-full border-none bg-card/95 backdrop-blur-sm">
        {children}
      </Card>
    </motion.div>
  );
};

FuturisticCard.Header = CardHeader;
FuturisticCard.Content = CardContent;
FuturisticCard.Footer = CardFooter;
FuturisticCard.Title = CardTitle;
FuturisticCard.Description = CardDescription;

export { FuturisticCard };