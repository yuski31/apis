import { Outlet } from "react-router-dom";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { DocsSidebar } from "./DocsSidebar";
import { DocsPager } from "./DocsPager";

export function DocsLayout() {
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <Header />
      <div className="container mx-auto flex-1 max-w-screen-2xl">
        <div className="flex">
          <DocsSidebar />
          <main className="flex-1 py-6 lg:py-8">
            <div className="w-full min-w-0">
              <Outlet />
              <DocsPager />
            </div>
          </main>
        </div>
      </div>
      <Footer />
    </div>
  );
}