import { useLocation, Link } from "react-router-dom";
import { docsConfig } from "@/data/docs";
import { cn } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";
import { ArrowLeft, ArrowRight } from "lucide-react";

export function DocsPager() {
  const location = useLocation();
  const pager = getPagerForDoc(location.pathname);

  if (!pager) {
    return null;
  }

  return (
    <div className="flex flex-row items-center justify-between mt-8 pt-4 border-t border-border/40">
      {pager.prev ? (
        <Link
          to={pager.prev.href}
          className={cn(buttonVariants({ variant: "outline" }))}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          {pager.prev.title}
        </Link>
      ) : <div />}
      {pager.next ? (
        <Link
          to={pager.next.href}
          className={cn(buttonVariants({ variant: "outline" }), "ml-auto")}
        >
          {pager.next.title}
          <ArrowRight className="ml-2 h-4 w-4" />
        </Link>
      ) : <div />}
    </div>
  );
}

function getPagerForDoc(pathname: string) {
  const flattenedLinks = docsConfig.flatMap((group) => group.items);
  const activeIndex = flattenedLinks.findIndex((link) => link.href === pathname);

  if (activeIndex === -1) {
    return null;
  }

  const prev = activeIndex > 0 ? flattenedLinks[activeIndex - 1] : null;
  const next = activeIndex < flattenedLinks.length - 1 ? flattenedLinks[activeIndex + 1] : null;

  return { prev, next };
}