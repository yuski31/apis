import { Link, useLocation } from "react-router-dom";
import { docsConfig } from "@/data/docs";
import { cn } from "@/lib/utils";

export function DocsSidebar() {
  const location = useLocation();

  return (
    <aside className="hidden lg:block w-64 flex-shrink-0 pr-8">
      <div className="sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto py-6">
        <nav className="w-full">
          {docsConfig.map((group, index) => (
            <div key={index} className="pb-8">
              <h4 className="mb-2 rounded-md px-2 py-1 text-sm font-semibold">
                {group.title}
              </h4>
              <div className="grid grid-flow-row auto-rows-max text-sm">
                {group.items.map((item) => (
                  <Link
                    key={item.href}
                    to={item.href}
                    className={cn(
                      "group flex w-full items-center rounded-md border border-transparent px-2 py-1.5 hover:underline",
                      item.disabled && "cursor-not-allowed opacity-60",
                      location.pathname === item.href
                        ? "font-medium text-primary"
                        : "text-muted-foreground"
                    )}
                  >
                    {item.title}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </nav>
      </div>
    </aside>
  );
}