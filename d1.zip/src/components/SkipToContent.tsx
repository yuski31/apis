export const SkipToContent = () => {
  return (
    <a
      href="#main-content"
      className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 z-[9999] bg-background text-foreground px-4 py-2 rounded-lg shadow-lg"
    >
      Skip to main content
    </a>
  );
};