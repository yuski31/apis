"use client";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CodeBlock } from "./CodeBlock";

const codeSnippets = {
  curl: `curl https://api.shin.example/v1/chat.completions \\
  -H "Authorization: Bearer $SHIN_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "shin-chat-large",
    "messages": [{
      "role": "user",
      "content": "What is the capital of Japan?"
    }]
  }'`,
  node: `import Shin from 'shin';

const shin = new Shin({
  apiKey: process.env.SHIN_API_KEY,
});

async function main() {
  const completion = await shin.chat.completions.create({
    messages: [{ role: 'user', content: 'What is the capital of Japan?' }],
    model: 'shin-chat-large',
  });

  console.log(completion.choices[0].message.content);
}

main();`,
  python: `from shin import Shin

client = Shin(
  api_key="YOUR_SHIN_API_KEY",
)

completion = client.chat.completions.create(
  model="shin-chat-large",
  messages=[
    {"role": "user", "content": "What is the capital of Japan?"}
  ]
)

print(completion.choices[0].message.content)`,
};

export const CodeTabs = () => {
  return (
    <Tabs defaultValue="curl" className="w-full max-w-xl mx-auto">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="curl">cURL</TabsTrigger>
        <TabsTrigger value="node">Node.js</TabsTrigger>
        <TabsTrigger value="python">Python</TabsTrigger>
      </TabsList>
      <TabsContent value="curl">
        <CodeBlock code={codeSnippets.curl} />
      </TabsContent>
      <TabsContent value="node">
        <CodeBlock code={codeSnippets.node} />
      </TabsContent>
      <TabsContent value="python">
        <CodeBlock code={codeSnippets.python} />
      </TabsContent>
    </Tabs>
  );
};