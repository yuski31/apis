import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export const Cta = () => {
  return (
    <section className="py-20 md:py-28 border-t border-border/40">
      <div className="container max-w-screen-lg text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Start Building with Shin Today
        </h2>
        <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
          Explore our powerful APIs, dive into the documentation, and start building your next intelligent application. No credit card required to get started.
        </p>
        <div className="flex justify-center gap-4">
          <Button size="lg" asChild>
            <Link to="/signup">Sign Up for Free</Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link to="/pricing">View Pricing</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};