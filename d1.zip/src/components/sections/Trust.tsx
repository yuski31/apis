import { ShieldCheck, Lock, DatabaseZap } from "lucide-react";
import { FuturisticCard } from "@/components/FuturisticCard";

const trustFeatures = [
  {
    icon: <ShieldCheck className="h-8 w-8 text-primary" />,
    title: "Enterprise-Grade Security",
    description: "We follow industry best practices to ensure your data is safe and secure.",
  },
  {
    icon: <Lock className="h-8 w-8 text-primary" />,
    title: "End-to-End Encryption",
    description: "All data is encrypted in transit and at rest using industry-standard protocols.",
  },
  {
    icon: <DatabaseZap className="h-8 w-8 text-primary" />,
    title: "Data Privacy Focused",
    description: "Committed to data privacy and protection for all our users worldwide.",
  },
];

export const Trust = () => {
  return (
    <section className="py-20 md:py-28 bg-card/30">
      <div className="container max-w-screen-2xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">Built on a Foundation of Trust</h2>
          <p className="text-muted-foreground mt-2">Your security and privacy are our top priorities.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {trustFeatures.map((feature) => (
            <FuturisticCard key={feature.title} className="text-center">
              <FuturisticCard.Header>
                <div className="mb-4 flex justify-center">{feature.icon}</div>
                <FuturisticCard.Title>{feature.title}</FuturisticCard.Title>
                <FuturisticCard.Description className="pt-2">{feature.description}</FuturisticCard.Description>
              </FuturisticCard.Header>
            </FuturisticCard>
          ))}
        </div>
      </div>
    </section>
  );
};