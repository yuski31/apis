import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { AnimatedGridBackground } from "@/components/AnimatedGridBackground";
import { motion } from "framer-motion";
import { staggerContainer, fadeIn } from "@/lib/animations";
import { CodeTabs } from "../CodeTabs";

export const Hero = () => {
  return (
    <motion.section
      className="relative w-full pt-20 md:pt-28 pb-12 md:pb-16 overflow-hidden"
      variants={staggerContainer}
      initial="hidden"
      animate="show"
    >
      <AnimatedGridBackground />
      <div className="container max-w-screen-2xl text-center">
        <motion.h1
          variants={fadeIn}
          className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter mb-4 bg-clip-text text-transparent bg-gradient-to-br from-primary via-foreground to-secondary bg-200% animate-animated-gradient"
        >
          AI Building Blocks for Developers
        </motion.h1>
        <motion.p
          variants={fadeIn}
          className="max-w-2xl mx-auto text-lg md:text-xl text-muted-foreground mb-8"
        >
          Reliable, scalable AI APIs for text, embeddings, vision, and speech—simple pricing, great docs, and transparent limits.
        </motion.p>
        <motion.div
          variants={fadeIn}
          className="flex justify-center gap-4 mb-12"
        >
          <Button size="lg" asChild>
            <Link to="/signup">Start Building for Free</Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link to="/docs">Read Docs</Link>
          </Button>
        </motion.div>
        <motion.div variants={fadeIn}>
          <CodeTabs />
        </motion.div>
      </div>
    </motion.section>
  );
};