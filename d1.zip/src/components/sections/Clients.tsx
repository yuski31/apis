export const Clients = () => {
  const logos = ["TechCorp", "Innovate Inc.", "Data Solutions", "Future Systems", "AI Ventures", "Quantum Leap"];

  return (
    <section className="py-20 md:py-28">
      <div className="container max-w-screen-2xl">
        <h2 className="text-center text-2xl font-semibold text-muted-foreground mb-8">
          Trusted by the world's most innovative companies
        </h2>
        <div className="relative overflow-hidden">
          <div className="flex animate-marquee whitespace-nowrap">
            {logos.concat(logos).map((logo, index) => (
              <div key={index} className="mx-8 text-2xl text-muted-foreground/70 font-medium">
                {logo}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};