import { MessageSquarePlus, BookText, Eye, Mic, ShieldCheck, Webhook, FastForward, LineChart } from "lucide-react";
import { FuturisticCard } from "@/components/FuturisticCard";

const features = [
  {
    icon: <MessageSquarePlus className="h-8 w-8 text-primary" />,
    title: "Text Generation",
    description: "Access powerful language models for chat, summarization, and content creation.",
  },
  {
    icon: <BookText className="h-8 w-8 text-primary" />,
    title: "Embeddings",
    description: "Create state-of-the-art vector embeddings for semantic search and classification.",
  },
  {
    icon: <Eye className="h-8 w-8 text-primary" />,
    title: "Vision",
    description: "Analyze images to understand content, detect objects, and read text (OCR).",
  },
  {
    icon: <Mic className="h-8 w-8 text-primary" />,
    title: "Speech",
    description: "Transcribe audio to text with high accuracy and generate natural-sounding speech.",
  },
  {
    icon: <ShieldCheck className="h-8 w-8 text-primary" />,
    title: "Moderation",
    description: "Ensure your platform is safe with our fast and reliable content moderation API.",
  },
  {
    icon: <Webhook className="h-8 w-8 text-primary" />,
    title: "Webhooks",
    description: "Get notified of asynchronous events and build event-driven integrations.",
  },
  {
    icon: <FastForward className="h-8 w-8 text-primary" />,
    title: "Streaming",
    description: "Receive real-time responses for interactive, low-latency applications.",
  },
  {
    icon: <LineChart className="h-8 w-8 text-primary" />,
    title: "Observability",
    description: "Monitor your usage, performance, and costs with our detailed analytics dashboard.",
  },
];

export const Features = () => {
  return (
    <section className="py-20 md:py-28">
      <div className="container max-w-screen-2xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">A Unified API for All Your AI Needs</h2>
          <p className="text-muted-foreground mt-2">One simple interface to access a suite of powerful, reliable AI models.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature) => (
            <FuturisticCard key={feature.title}>
              <FuturisticCard.Header>
                <div className="mb-4">{feature.icon}</div>
                <FuturisticCard.Title>{feature.title}</FuturisticCard.Title>
                <FuturisticCard.Description className="pt-2">{feature.description}</FuturisticCard.Description>
              </FuturisticCard.Header>
            </FuturisticCard>
          ))}
        </div>
      </div>
    </section>
  );
};