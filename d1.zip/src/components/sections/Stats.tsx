"use client";
import { useState, useEffect } from 'react';

const AnimatedCounter = ({ target, duration = 2000 }: { target: number, duration?: number }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let start = 0;
    const end = target;
    if (start === end) return;

    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * (end - start) + start));
      if (progress < 1) {
        window.requestAnimationFrame(step);
      }
    };
    window.requestAnimationFrame(step);
  }, [target, duration]);

  return <>{count.toLocaleString()}</>;
};

const stats = [
  { value: 500, suffix: "M+", label: "API Calls per Month" },
  { value: 99, suffix: ".99%", label: "Uptime Guarantee" },
  { value: 1000, suffix: "+", label: "Happy Customers" },
  { value: 80, suffix: "ms", label: "Average Response Time" },
];

export const Stats = () => {
  return (
    <section className="py-20 md:py-28 bg-card/30">
      <div className="container max-w-screen-2xl">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
          {stats.map((stat) => (
            <div key={stat.label}>
              <div className="mb-2 text-4xl md:text-5xl font-bold text-primary">
                <AnimatedCounter target={stat.value} />
                <span>{stat.suffix}</span>
              </div>
              <p className="text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};