"use client";
import { useState, useEffect, useRef } from 'react';

const AnimatedPrice = ({ price, duration = 500 }: { price: number, duration?: number }) => {
  const [displayPrice, setDisplayPrice] = useState(0);
  const prevPriceRef = useRef(0);

  useEffect(() => {
    const start = prevPriceRef.current;
    const end = price;
    if (start === end) {
      setDisplayPrice(end);
      return;
    };

    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const current = progress * (end - start) + start;
      setDisplayPrice(Math.floor(current));
      if (progress < 1) {
        window.requestAnimationFrame(step);
      } else {
        setDisplayPrice(end);
        prevPriceRef.current = end;
      }
    };
    window.requestAnimationFrame(step);
    
    return () => {
        prevPriceRef.current = price;
    }
  }, [price, duration]);

  return <>{displayPrice}</>;
};

export default AnimatedPrice;