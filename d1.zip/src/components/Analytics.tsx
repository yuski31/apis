import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
  }
}

const GA4_ID = import.meta.env.VITE_GA4_ID;

export const Analytics = () => {
  const location = useLocation();

  useEffect(() => {
    if (!GA4_ID) {
      console.warn("Google Analytics ID is not set. Skipping analytics initialization.");
      return;
    }

    const scriptId = 'ga-gtag';
    if (document.getElementById(scriptId)) return;

    const script = document.createElement('script');
    script.id = scriptId;
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${GA4_ID}`;
    document.head.appendChild(script);

    window.dataLayer = window.dataLayer || [];
    function gtag(...args: any[]) {
      window.dataLayer.push(args);
    }
    gtag('js', new Date());
    gtag('config', GA4_ID);

  }, []);

  useEffect(() => {
    if (window.gtag && GA4_ID) {
      window.gtag('config', GA4_ID, {
        page_path: location.pathname + location.search,
      });
    }
  }, [location]);

  return null;
};