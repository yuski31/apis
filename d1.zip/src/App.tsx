import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Products from "./pages/Products";
import Pricing from "./pages/Pricing";
import Introduction from "./pages/docs/Introduction";
import QuickStart from "./pages/docs/QuickStart";
import Authentication from "./pages/docs/Authentication";
import RateLimits from "./pages/docs/core-concepts/RateLimits";
import Errors from "./pages/docs/core-concepts/Errors";
import Pagination from "./pages/docs/core-concepts/Pagination";
import Webhooks from "./pages/docs/core-concepts/Webhooks";
import Streaming from "./pages/docs/core-concepts/Streaming";
import TextGeneration from "./pages/docs/api/TextGeneration";
import Embeddings from "./pages/docs/api/Embeddings";
import Vision from "./pages/docs/api/Vision";
import Blog from "./pages/Blog";
import BlogPost from "./pages/BlogPost";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import Status from "./pages/Status";
import Careers from "./pages/Careers";
import Changelog from "./pages/Changelog";
import TextGenerationDemo from "./pages/demos/TextGenerationDemo";
import VisionDemo from "./pages/demos/VisionDemo";
import Signup from "./pages/Signup";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/NotFound";
import { ThemeProvider } from "./components/ThemeProvider";
import { DocsLayout } from "./components/layout/DocsLayout";
import { Analytics } from "./components/Analytics";
import { JsonLd } from "./components/JsonLd";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider defaultTheme="dark" storageKey="shin-theme">
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Analytics />
          <JsonLd />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/products" element={<Products />} />
            <Route path="/pricing" element={<Pricing />} />
            
            <Route path="/docs" element={<DocsLayout />}>
              <Route index element={<Introduction />} />
              <Route path="quick-start" element={<QuickStart />} />
              <Route path="authentication" element={<Authentication />} />
              <Route path="core-concepts/rate-limits" element={<RateLimits />} />
              <Route path="core-concepts/errors" element={<Errors />} />
              <Route path="core-concepts/pagination" element={<Pagination />} />
              <Route path="core-concepts/webhooks" element={<Webhooks />} />
              <Route path="core-concepts/streaming" element={<Streaming />} />
              <Route path="api/text-generation" element={<TextGeneration />} />
              <Route path="api/embeddings" element={<Embeddings />} />
              <Route path="api/vision" element={<Vision />} />
            </Route>

            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<BlogPost />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/status" element={<Status />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/changelog" element={<Changelog />} />
            <Route path="/demos/text-generation" element={<TextGenerationDemo />} />
            <Route path="/demos/vision" element={<VisionDemo />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/login" element={<Login />} />
            <Route path="/dashboard" element={<Dashboard />} />

            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;