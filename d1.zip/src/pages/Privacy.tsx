import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { PageMetadata } from "@/components/PageMetadata";

const Privacy = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata
        title="Privacy Policy"
        description="Learn how Shin AI collects, uses, and protects your data."
      />
      <Header />
      <main className="flex-grow">
        <section className="py-20 md:py-28">
          <div className="container max-w-screen-lg">
            <article className="prose prose-invert max-w-none">
              <h1>Privacy Policy</h1>
              <p>Last updated: July 19, 2024</p>
              <p>This Privacy Policy describes Our policies and procedures on the collection, use and disclosure of Your information when You use the Service and tells You about Your privacy rights and how the law protects You.</p>

              <h2>Collecting and Using Your Personal Data</h2>
              <h3>Types of Data Collected</h3>
              <h4>Personal Data</h4>
              <p>While using Our Service, We may ask You to provide Us with certain personally identifiable information that can be used to contact or identify You. Personally identifiable information may include, but is not limited to: Email address, First name and last name, Usage Data.</p>
              <h4>Usage Data</h4>
              <p>Usage Data is collected automatically when using the Service. Usage Data may include information such as Your Device's Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that You visit, the time and date of Your visit, the time spent on those pages, unique device identifiers and other diagnostic data.</p>

              <h2>Use of Your Personal Data</h2>
              <p>The Company may use Personal Data for the following purposes: to provide and maintain our Service, to manage Your Account, for the performance of a contract, to contact You, to provide You with news, special offers and general information about other goods, services and events which we offer.</p>

              <h2>Contact Us</h2>
              <p>If you have any questions about this Privacy Policy, You can contact us by visiting the contact page on our website.</p>
            </article>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Privacy;