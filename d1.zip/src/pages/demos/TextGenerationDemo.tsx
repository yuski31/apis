import { useState } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { PageMetadata } from "@/components/PageMetadata";
import { Bot } from "lucide-react";

const TextGenerationDemo = () => {
  const [prompt, setPrompt] = useState("What is the capital of Japan?");
  const [response, setResponse] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt) return;

    setIsLoading(true);
    setResponse("");

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Simulated response
    setResponse("The capital of Japan is Tokyo. It is the world's most populous metropolis and is known for its imperial palace, numerous shrines and temples, and modern skyscrapers.");
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata
        title="Text Generation Demo"
        description="Try our Natural Language Processing API in real-time. Enter a prompt and see the AI generate a response."
      />
      <Header />
      <main className="flex-grow">
        <section className="py-20 md:py-28">
          <div className="container max-w-screen-md">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold">Text Generation Demo</h1>
              <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
                Experience the power of our NLP API. Enter a prompt below to see the AI in action.
              </p>
            </div>
            <Card className="bg-card/50">
              <CardHeader>
                <CardTitle>Live Demo</CardTitle>
                <CardDescription>This is a simulated response for demonstration purposes.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="prompt">Your Prompt</Label>
                    <Textarea
                      id="prompt"
                      placeholder="e.g., What is the capital of Japan?"
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      rows={3}
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? "Generating..." : "Generate Response"}
                  </Button>
                </form>
                {(isLoading || response) && (
                  <div className="mt-6 pt-6 border-t border-border/40">
                    <h3 className="text-lg font-semibold mb-4 flex items-center">
                      <Bot className="h-5 w-5 mr-2 text-primary" />
                      AI Response
                    </h3>
                    {isLoading ? (
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-3/4" />
                      </div>
                    ) : (
                      <p className="text-muted-foreground">{response}</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default TextGenerationDemo;