import { useState } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { PageMetadata } from "@/components/PageMetadata";
import { Eye, Tag } from "lucide-react";

interface BoundingBox {
  label: string;
  confidence: number;
  box: [number, number, number, number]; // [x, y, width, height] in percentage
}

const VisionDemo = () => {
  const [imageUrl, setImageUrl] = useState("https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?q=80&w=2043&auto=format&fit=crop");
  const [analysisResult, setAnalysisResult] = useState<BoundingBox[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageUrl) return;

    setIsLoading(true);
    setAnalysisResult(null);
    setError(null);

    // Simulate API call and image loading
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Simulated response
    const mockResponse: BoundingBox[] = [
      { label: "Cat", confidence: 0.98, box: [15, 20, 60, 70] },
      { label: "Sofa", confidence: 0.92, box: [5, 45, 90, 50] },
    ];
    
    setAnalysisResult(mockResponse);
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata
        title="Computer Vision Demo"
        description="Try our Computer Vision API. Provide an image URL to detect objects and analyze content."
      />
      <Header />
      <main className="flex-grow">
        <section className="py-20 md:py-28">
          <div className="container max-w-screen-lg">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold">Computer Vision Demo</h1>
              <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
                See our Vision API in action. Enter an image URL below to detect objects.
              </p>
            </div>
            <Card className="bg-card/50">
              <CardHeader>
                <CardTitle>Live Demo</CardTitle>
                <CardDescription>This is a simulated response for demonstration purposes.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4 mb-6">
                  <div className="space-y-2">
                    <Label htmlFor="imageUrl">Image URL</Label>
                    <div className="flex gap-2">
                      <Input
                        id="imageUrl"
                        placeholder="https://example.com/image.jpg"
                        value={imageUrl}
                        onChange={(e) => setImageUrl(e.target.value)}
                      />
                      <Button type="submit" disabled={isLoading} className="min-w-fit">
                        {isLoading ? "Analyzing..." : "Analyze Image"}
                      </Button>
                    </div>
                  </div>
                </form>
                
                <div className="w-full aspect-video bg-card rounded-lg flex items-center justify-center relative overflow-hidden border border-border/40">
                  {isLoading && <Skeleton className="w-full h-full" />}
                  {!isLoading && imageUrl && (
                    <>
                      <img src={imageUrl} alt="Analysis subject" className="w-full h-full object-contain" onError={() => setError("Failed to load image. Please check the URL.")} />
                      {analysisResult?.map((item, index) => (
                        <div
                          key={index}
                          className="absolute border-2 border-primary rounded-sm"
                          style={{
                            left: `${item.box[0]}%`,
                            top: `${item.box[1]}%`,
                            width: `${item.box[2]}%`,
                            height: `${item.box[3]}%`,
                          }}
                        >
                          <span className="absolute -top-7 left-0 bg-primary text-primary-foreground text-xs font-semibold px-2 py-1 rounded-sm">
                            {item.label} ({(item.confidence * 100).toFixed(0)}%)
                          </span>
                        </div>
                      ))}
                    </>
                  )}
                  {error && <p className="text-destructive">{error}</p>}
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default VisionDemo;