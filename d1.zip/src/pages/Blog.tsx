import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { blogPosts } from "@/data/blog";
import { PageMetadata } from "@/components/PageMetadata";

const Blog = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata
        title="Blog"
        description="Insights, tutorials, and news from the forefront of artificial intelligence."
      />
      <Header />
      <main className="flex-grow">
        <section className="py-20 md:py-28">
          <div className="container max-w-screen-lg">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold">Shin AI Blog</h1>
              <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
                Insights, tutorials, and news from the forefront of artificial intelligence.
              </p>
            </div>
            <div className="grid grid-cols-1 gap-8">
              {blogPosts.map((post) => (
                <Link to={`/blog/${post.slug}`} key={post.slug}>
                  <Card className="bg-card/50 border-border/50 hover:border-primary/50 transition-colors h-full">
                    <CardHeader>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-primary font-semibold">{post.category}</span>
                        <span className="text-sm text-muted-foreground">{post.date}</span>
                      </div>
                      <CardTitle className="text-2xl">{post.title}</CardTitle>
                      <CardDescription className="pt-2">{post.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center font-semibold text-primary">
                        Read More <ArrowRight className="h-4 w-4 ml-2" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Blog;