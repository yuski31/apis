import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { FuturisticCard } from "@/components/FuturisticCard";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Cpu, Eye, LineChart, Mic, BrainCircuit } from "lucide-react";
import { PageMetadata } from "@/components/PageMetadata";
import { Link } from "react-router-dom";

const apiServices = [
  {
    id: "nlp",
    icon: <Cpu className="h-8 w-8 text-primary" />,
    title: "Natural Language Processing API",
    description: "Analyze, understand, and generate human language with our advanced NLP models.",
    features: ["Sentiment Analysis", "Text Summarization", "Named Entity Recognition", "Language Translation"],
    docsPath: "/docs/api/text-generation",
    demoPath: "/demos/text-generation",
  },
  {
    id: "vision",
    icon: <Eye className="h-8 w-8 text-primary" />,
    title: "Computer Vision API",
    description: "Extract rich information from images to categorize and process visual data.",
    features: ["Object Detection", "Image Recognition", "Optical Character Recognition (OCR)", "Facial Analysis"],
    docsPath: "/docs/api/vision",
    demoPath: "/demos/vision",
  },
  {
    id: "analytics",
    icon: <LineChart className="h-8 w-8 text-primary" />,
    title: "Predictive Analytics API",
    description: "Leverage historical data to forecast future trends and make informed decisions.",
    features: ["Demand Forecasting", "Customer Churn Prediction", "Fraud Detection", "Personalized Recommendations"],
    docsPath: "/docs",
  },
  {
    id: "speech",
    icon: <Mic className="h-8 w-8 text-primary" />,
    title: "Speech Recognition & Synthesis API",
    description: "Convert spoken language into text and text into natural-sounding speech.",
    features: ["Real-time Transcription", "Voice Commands", "Text-to-Speech (TTS)", "Speaker Identification"],
    docsPath: "/docs",
  },
  {
    id: "custom",
    icon: <BrainCircuit className="h-8 w-8 text-primary" />,
    title: "Custom AI Model Training",
    description: "Develop bespoke AI models tailored to your unique business challenges and datasets.",
    features: ["Personalized Model Architecture", "Proprietary Data Integration", "Continuous Model Improvement", "Dedicated AI Expertise"],
    docsPath: "/contact",
  },
];

const Products = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata
        title="Our Products"
        description="Explore our suite of AI-powered API services, including NLP, Computer Vision, and Predictive Analytics."
      />
      <Header />
      <main className="flex-grow">
        <section className="py-20 md:py-28">
          <div className="container max-w-screen-2xl">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold">Explore Our AI-Powered API Services</h1>
              <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
                Cutting-edge solutions designed to seamlessly integrate powerful intelligence into your applications.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {apiServices.map((service) => (
                <FuturisticCard key={service.title} className="flex flex-col">
                  <FuturisticCard.Header>
                    <div className="mb-4">{service.icon}</div>
                    <FuturisticCard.Title>{service.title}</FuturisticCard.Title>
                    <FuturisticCard.Description className="pt-2">{service.description}</FuturisticCard.Description>
                  </FuturisticCard.Header>
                  <FuturisticCard.Content className="flex-grow flex flex-col justify-between">
                    <ul className="space-y-2 mb-6">
                      {service.features.map((feature) => (
                        <li key={feature} className="flex items-center text-sm">
                          <CheckCircle2 className="h-4 w-4 mr-2 text-primary" />
                          <span className="text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="flex gap-4">
                        <Button asChild>
                            <Link to={service.docsPath}>View Documentation</Link>
                        </Button>
                        {service.demoPath ? (
                            <Button variant="outline" asChild>
                                <Link to={service.demoPath}>Try Demo</Link>
                            </Button>
                        ) : (
                            <Button variant="outline" disabled>Try Demo</Button>
                        )}
                    </div>
                  </FuturisticCard.Content>
                </FuturisticCard>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Products;