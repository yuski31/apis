import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { PageMetadata } from "@/components/PageMetadata";

const Careers = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata
        title="Careers"
        description="Join us in building the future of AI for developers."
      />
      <Header />
      <main className="flex-grow">
        <section className="py-20 md:py-28">
          <div className="container max-w-screen-lg text-center">
            <h1 className="text-4xl md:text-5xl font-bold">Careers</h1>
            <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
              Join us in building the future of AI for developers.
            </p>
            <div className="mt-12">
              <h2 className="text-2xl font-semibold">Current Openings</h2>
              <p className="text-muted-foreground mt-4">
                We don't have any open positions at the moment, but we're always looking for talented people. Feel free to send your resume to careers@shin.example.
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Careers;