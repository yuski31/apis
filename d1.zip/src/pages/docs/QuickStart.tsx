import { CodeTabs } from "@/components/CodeTabs";
import { CodeBlock } from "@/components/CodeBlock";

const QuickStart = () => {
  const installCommands = `# Node.js
npm install shin-ai

# Python
pip install shin-ai`;

  return (
    <div className="prose prose-invert max-w-none">
      <h1>Quick Start</h1>
      <p>Follow this guide to make your first API call to Shin AI in just a few minutes.</p>
      
      <h2>1. Get your API Key</h2>
      <p>First, you need an API key. If you don't have one, sign up for a free account on our dashboard and create a new key.</p>

      <h2>2. Install an SDK (Optional)</h2>
      <p>While you can use our API with any HTTP client, we recommend using one of our official SDKs for a better developer experience. For this guide, we'll show examples using cURL, Node.js, and Python.</p>
      <p>To install our Node.js or Python libraries:</p>
      <CodeBlock code={installCommands} />

      <h2>3. Make your first request</h2>
      <p>Now you're ready to make your first request. The example below shows how to use our Text Generation API to create a simple chat completion.</p>
      <p>Replace <code>$SHIN_API_KEY</code> or <code>YOUR_SHIN_API_KEY</code> with the API key you created in step 1.</p>
      <div className="not-prose">
        <CodeTabs />
      </div>

      <h2>Next Steps</h2>
      <p>Congratulations! You've successfully made your first API call. From here, you can explore the rest of our API reference to learn about other endpoints like Embeddings and Vision.</p>
    </div>
  );
};

export default QuickStart;