import { CodeBlock } from "@/components/CodeBlock";

const Streaming = () => {
  const streamingRequest = `curl https://api.shin.example/v1/chat.completions \\
  -H "Authorization: Bearer $SHIN_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "shin-chat-large",
    "messages": [{"role": "user", "content": "Tell me a short story."}],
    "stream": true
  }'`;
  const streamingResponse = `data: {"id":"chatcmpl-123","object":"chat.completion.chunk","created":1694268190,"model":"shin-chat-large","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}]}

data: {"id":"chatcmpl-123","object":"chat.completion.chunk","created":1694268190,"model":"shin-chat-large","choices":[{"index":0,"delta":{"content":"Once"},"finish_reason":null}]}

data: {"id":"chatcmpl-123","object":"chat.completion.chunk","created":1694268190,"model":"shin-chat-large","choices":[{"index":0,"delta":{"content":" upon"},"finish_reason":null}]}

data: {"id":"chatcmpl-123","object":"chat.completion.chunk","created":1694268190,"model":"shin-chat-large","choices":[{"index":0,"delta":{"content":" a"},"finish_reason":null}]}

data: {"id":"chatcmpl-123","object":"chat.completion.chunk","created":1694268190,"model":"shin-chat-large","choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}

data: [DONE]`;

  return (
    <div className="prose prose-invert max-w-none">
      <h1>Streaming</h1>
      <p>For certain endpoints, like Chat Completions, we support streaming responses. This allows you to receive the generated content in real-time as it's being produced, rather than waiting for the entire response to be ready. This is ideal for creating interactive, chatbot-like experiences.</p>

      <h2>How it Works</h2>
      <p>To enable streaming, you simply set the <code>stream</code> parameter to <code>true</code> in your request. The API will then respond with a stream of Server-Sent Events (SSE).</p>
      <p>Each event in the stream is a JSON object representing a small chunk of the overall response. The <code>delta</code> field contains the new piece of content. The final event in the stream will have a <code>finish_reason</code>, and the stream will be terminated by a <code>data: [DONE]</code> message.</p>

      <h3>Example Streaming Request</h3>
      <CodeBlock code={streamingRequest} />

      <h3>Example Streamed Response</h3>
      <p>Below is a simplified representation of the data events you would receive. Your client will need to parse these events and concatenate the <code>content</code> from each <code>delta</code> to reconstruct the full message.</p>
      <CodeBlock code={streamingResponse} />
    </div>
  );
};

export default Streaming;