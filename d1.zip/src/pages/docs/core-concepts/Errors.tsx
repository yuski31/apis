import { CodeBlock } from "@/components/CodeBlock";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const Errors = () => {
  const errorSchema = `{
  "error": {
    "type": "invalid_request_error",
    "message": "The 'model' parameter is required.",
    "code": "missing_parameter"
  }
}`;

  return (
    <div className="prose prose-invert max-w-none">
      <h1>Errors</h1>
      <p>Shin AI uses conventional HTTP status codes to indicate the success or failure of an API request. In general, codes in the <code>2xx</code> range indicate success, codes in the <code>4xx</code> range indicate a client-side error (e.g., a problem with your request), and codes in the <code>5xx</code> range indicate a server-side error.</p>

      <h2>Error Response Schema</h2>
      <p>When an API request fails, we return a JSON object in the response body with a consistent structure to help you debug the issue.</p>
      <CodeBlock code={errorSchema} />
      <ul>
        <li><strong>type</strong>: A machine-readable string indicating the type of error.</li>
        <li><strong>message</strong>: A human-readable description of the error.</li>
        <li><strong>code</strong> (optional): A short string code for the specific error, which can be useful for programmatic error handling.</li>
      </ul>

      <h2>Common HTTP Status Codes</h2>
      <div className="not-prose">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Status Code</TableHead>
              <TableHead>Meaning</TableHead>
              <TableHead>Description</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell>400 Bad Request</TableCell>
              <TableCell>Invalid Request</TableCell>
              <TableCell>The request was malformed, often due to missing a required parameter or invalid JSON.</TableCell>
            </TableRow>
            <TableRow>
              <TableCell>401 Unauthorized</TableCell>
              <TableCell>Authentication Error</TableCell>
              <TableCell>No valid API key was provided.</TableCell>
            </TableRow>
            <TableRow>
              <TableCell>404 Not Found</TableCell>
              <TableCell>Not Found</TableCell>
              <TableCell>The requested resource does not exist.</TableCell>
            </TableRow>
            <TableRow>
              <TableCell>429 Too Many Requests</TableCell>
              <TableCell>Rate Limit Exceeded</TableCell>
              <TableCell>You have hit your rate limit. Please wait before making new requests.</TableCell>
            </TableRow>
            <TableRow>
              <TableCell>500 Internal Server Error</TableCell>
              <TableCell>Server Error</TableCell>
              <TableCell>Something went wrong on our end. Please try again later.</TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default Errors;