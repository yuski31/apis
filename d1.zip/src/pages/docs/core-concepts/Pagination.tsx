import { CodeBlock } from "@/components/CodeBlock";

const Pagination = () => {
  const paginationRequest = `curl "https://api.shin.example/v1/models?limit=10&starting_after=model_abc" \\
  -H "Authorization: Bearer $SHIN_API_KEY"`;
  const paginationResponse = `{
  "object": "list",
  "data": [
    // ... 10 model objects
  ],
  "has_more": true,
  "next_page": "https://api.shin.example/v1/models?limit=10&starting_after=model_xyz"
}`;

  return (
    <div className="prose prose-invert max-w-none">
      <h1>Pagination</h1>
      <p>For API endpoints that return a list of objects, we use cursor-based pagination. This method provides a more stable and efficient way to navigate through large sets of data compared to traditional offset-based pagination.</p>

      <h2>How it Works</h2>
      <p>Our list endpoints accept two optional parameters to control pagination:</p>
      <ul>
        <li><code>limit</code> (integer, optional, default: 20): The maximum number of objects to return, between 1 and 100.</li>
        <li><code>starting_after</code> (string, optional): A cursor for pagination. This is the ID of the last object from the previous page.</li>
      </ul>

      <h2>Navigating Pages</h2>
      <p>The response from a list endpoint will include a <code>has_more</code> boolean property. If <code>true</code>, it means there are more objects available. The response will also contain a <code>next_page</code> URL, which you can use to fetch the next set of results directly.</p>
      <p>To fetch the next page, you take the ID of the last object in the current list and use it as the <code>starting_after</code> parameter in your next request.</p>

      <h3>Example Request</h3>
      <CodeBlock code={paginationRequest} />

      <h3>Example Response</h3>
      <CodeBlock code={paginationResponse} />
    </div>
  );
};

export default Pagination;