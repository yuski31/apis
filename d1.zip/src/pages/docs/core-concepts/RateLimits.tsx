import { CodeBlock } from "@/components/CodeBlock";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const RateLimits = () => {
  const headersExample = `HTTP/1.1 429 Too Many Requests
Content-Type: application/json
Retry-After: 60

{
  "error": {
    "type": "rate_limit_exceeded",
    "message": "You have exceeded your rate limit. Please try again in 60 seconds."
  }
}`;

  return (
    <div className="prose prose-invert max-w-none">
      <h1>Rate Limits</h1>
      <p>To ensure the stability and fair use of our platform for all users, Shin AI APIs are subject to rate limits. These limits define the number of requests you can make within a specific time window.</p>

      <h2>Understanding Rate Limits</h2>
      <p>Rate limits are applied on a per-API-key basis. The specific limits depend on your subscription plan. You can find the rate limits for your plan in your developer dashboard.</p>
      
      <div className="not-prose">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Plan</TableHead>
              <TableHead>Requests per Minute (RPM)</TableHead>
              <TableHead>Requests per Day (RPD)</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell>Free</TableCell>
              <TableCell>60</TableCell>
              <TableCell>5,000</TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Build</TableCell>
              <TableCell>600</TableCell>
              <TableCell>100,000</TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Scale</TableCell>
              <TableCell>3,500</TableCell>
              <TableCell>1,000,000</TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </div>

      <h2>Handling Rate Limit Errors</h2>
      <p>If you exceed your rate limit, the API will respond with an HTTP <code>429 Too Many Requests</code> status code. The response will also include a <code>Retry-After</code> header indicating how many seconds you should wait before making another request.</p>
      <p>It's crucial to build your application to handle these errors gracefully. We recommend implementing an exponential backoff strategy for retries.</p>
      
      <h3>Example 429 Response</h3>
      <CodeBlock code={headersExample} />
    </div>
  );
};

export default RateLimits;