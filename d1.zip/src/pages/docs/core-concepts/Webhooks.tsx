import { CodeBlock } from "@/components/CodeBlock";

const Webhooks = () => {
  const webhookPayload = `{
  "id": "evt_12345",
  "object": "event",
  "type": "transcription.succeeded",
  "created": 1677652288,
  "data": {
    "object": {
      "id": "txn_abcde",
      "status": "succeeded",
      "text": "This is the transcribed text."
      // ... other transcription object properties
    }
  }
}`;
  const webhookVerification = `const crypto = require('crypto');

const secret = 'whsec_your_webhook_secret';
const signature = req.headers['shin-signature'];
const payload = req.body;

const hash = crypto.createHmac('sha256', secret)
                   .update(JSON.stringify(payload))
                   .digest('hex');

if (hash === signature) {
  // Signature is valid
  res.sendStatus(200);
} else {
  // Signature is invalid
  res.sendStatus(400);
}`;

  return (
    <div className="prose prose-invert max-w-none">
      <h1>Webhooks</h1>
      <p>Webhooks allow you to receive real-time notifications about events that happen in your Shin AI account, such as the completion of an asynchronous job (e.g., a long audio transcription). This is more efficient than constantly polling our API to check for status changes.</p>

      <h2>Configuring Webhooks</h2>
      <p>You can configure your webhook endpoints from your developer dashboard. For each endpoint, you can specify the URL where you want to receive the payloads and select the specific event types you want to subscribe to.</p>

      <h2>Event Structure</h2>
      <p>All webhook payloads follow a consistent event structure. The <code>type</code> field indicates the event that occurred, and the <code>data.object</code> field contains the resource that was updated.</p>
      <h3>Example Payload (<code>transcription.succeeded</code>)</h3>
      <CodeBlock code={webhookPayload} />

      <h2>Verifying Signatures</h2>
      <p>To ensure that the webhook payloads you receive are genuinely from Shin AI, we sign each request with a secret key. Each webhook endpoint has its own secret, which you can find in your dashboard.</p>
      <p>The signature is included in the <code>Shin-Signature</code> HTTP header. You should compute the HMAC-SHA256 hash of the raw request body using your webhook secret and compare it to the signature in the header. If they match, you can be confident the request is authentic.</p>
      <h3>Example Verification (Node.js)</h3>
      <CodeBlock code={webhookVerification} />
    </div>
  );
};

export default Webhooks;