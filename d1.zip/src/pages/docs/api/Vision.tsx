import { CodeBlock } from "@/components/CodeBlock";

const Vision = () => {
  const curlExample = `curl https://api.shin.example/v1/vision/analyze \\
  -H "Authorization: Bearer $SHIN_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "shin-vision-standard",
    "image_url": "https://example.com/image.jpg",
    "features": ["objects", "ocr"]
  }'`;
  const responseExample = `{
  "model": "shin-vision-standard",
  "analysis": {
    "objects": [
      { "label": "Cat", "confidence": 0.98, "box": [100, 150, 300, 400] }
    ],
    "ocr": {
      "text": "Sample text found in image."
    }
  }
}`;

  return (
    <div className="prose prose-invert max-w-none">
      <h1>Vision</h1>
      <p>The Vision API allows you to analyze images to understand their content, detect objects, and extract text using Optical Character Recognition (OCR).</p>

      <h2>Analyze Image</h2>
      <p>The endpoint for this API is <code>/v1/vision/analyze</code>.</p>
      
      <h3>Request Body</h3>
      <ul>
        <li><code>model</code> (string, required): The ID of the model to use.</li>
        <li><code>image_url</code> (string, required): The URL of the image to analyze.</li>
        <li><code>features</code> (array of strings, required): The types of analysis to perform (e.g., "objects", "ocr").</li>
      </ul>

      <h3>Example Request (cURL)</h3>
      <CodeBlock code={curlExample} />

      <h3>Example Response</h3>
      <CodeBlock code={responseExample} />
    </div>
  );
};

export default Vision;