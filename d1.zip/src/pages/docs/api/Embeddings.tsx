import { CodeBlock } from "@/components/CodeBlock";

const Embeddings = () => {
  const curlExample = `curl https://api.shin.example/v1/embeddings \\
  -H "Authorization: Bearer $SHIN_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "shin-embed-small",
    "input": "The quick brown fox jumps over the lazy dog"
  }'`;
  const responseExample = `{
  "object": "list",
  "data": [
    {
      "object": "embedding",
      "embedding": [
        0.0023064255,
        -0.009327292,
        ...
        -0.0028842222,
      ],
      "index": 0
    }
  ],
  "model": "shin-embed-small",
  "usage": {
    "prompt_tokens": 8,
    "total_tokens": 8
  }
}`;

  return (
    <div className="prose prose-invert max-w-none">
      <h1>Embeddings</h1>
      <p>The Embeddings API creates a vector representation of a given input that can be easily consumed by machine learning models and algorithms.</p>

      <h2>Create Embeddings</h2>
      <p>The endpoint for this API is <code>/v1/embeddings</code>.</p>
      
      <h3>Request Body</h3>
      <ul>
        <li><code>model</code> (string, required): The ID of the model to use.</li>
        <li><code>input</code> (string or array of strings, required): The input text to embed.</li>
      </ul>

      <h3>Example Request (cURL)</h3>
      <CodeBlock code={curlExample} />

      <h3>Example Response</h3>
      <CodeBlock code={responseExample} />
    </div>
  );
};

export default Embeddings;