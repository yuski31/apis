import { CodeTabs } from "@/components/CodeTabs";
import { CodeBlock } from "@/components/CodeBlock";

const TextGeneration = () => {
  const responseExample = `{
  "id": "chatcmpl-123",
  "object": "chat.completion",
  "created": 1677652288,
  "model": "shin-chat-large",
  "choices": [{
    "index": 0,
    "message": {
      "role": "assistant",
      "content": "The capital of Japan is Tokyo."
    },
    "finish_reason": "stop"
  }],
  "usage": {
    "prompt_tokens": 9,
    "completion_tokens": 12,
    "total_tokens": 21
  }
}`;

  return (
    <div className="prose prose-invert max-w-none">
      <h1>Text Generation</h1>
      <p>The Text Generation API provides access to our most powerful language models. You can use it for a variety of tasks, including chat, content creation, summarization, and more.</p>

      <h2>Chat Completions</h2>
      <p>The primary endpoint for this API is <code>/v1/chat/completions</code>, which creates a model response for a given chat conversation.</p>
      
      <h3>Request Body</h3>
      <ul>
        <li><code>model</code> (string, required): The ID of the model to use.</li>
        <li><code>messages</code> (array, required): A list of messages describing the conversation so far.</li>
        <li><code>stream</code> (boolean, optional): If set, partial message deltas will be sent as server-sent events.</li>
      </ul>

      <h3>Example Request</h3>
      <div className="not-prose">
        <CodeTabs />
      </div>

      <h3>Example Response</h3>
      <CodeBlock code={responseExample} />
    </div>
  );
};

export default TextGeneration;