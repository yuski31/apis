import { CodeBlock } from "@/components/CodeBlock";

const Docs = () => {
  const apiKeyExample = `shin-ai --api-key YOUR_API_KEY`;
  const curlExample = `curl -X POST "https://api.shin.ai/v1/chat/completions" \\
-H "Authorization: Bearer YOUR_API_KEY" \\
-H "Content-Type: application/json" \\
-d '{"model": "shin-chat-large", "messages": [{"role": "user", "content": "What is the capital of Japan?"}]}'`;

  return (
    <div className="prose prose-invert max-w-none">
      <h1>Introduction</h1>
      <p>Welcome to the Shin AI documentation. Here you will find comprehensive guides, API references, and tutorials to help you get the most out of our platform.</p>
      <p>Shin AI provides a suite of powerful, enterprise-grade AI APIs that are designed for simplicity, speed, and scalability. Whether you're building a simple application or a complex enterprise system, our APIs provide the tools you need to integrate artificial intelligence seamlessly.</p>
      <p>Use the navigation on the left to explore the different sections of our documentation.</p>
      <h2>API Keys</h2>
      <p>Your API keys are used to authenticate your requests. You can manage your API keys from your account dashboard. Be sure to keep them secure and do not expose them in client-side code.</p>
      <CodeBlock code={apiKeyExample} />
      <h2>Example Request</h2>
      <p>Here is an example of how to make a request to the Text Generation API's chat completions endpoint using cURL:</p>
      <CodeBlock code={curlExample} />
    </div>
  );
};

export default Docs;