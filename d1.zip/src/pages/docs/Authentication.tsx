import { CodeBlock } from "@/components/CodeBlock";

const Authentication = () => {
  const authHeader = `Authorization: Bearer YOUR_API_KEY`;
  const curlExample = `curl https://api.shin.example/v1/models \\
  -H "Authorization: Bearer YOUR_API_KEY"`;
  const envVarExample = `export SHIN_API_KEY="YOUR_API_KEY"`;

  return (
    <div className="prose prose-invert max-w-none">
      <h1>Authentication</h1>
      <p>All API requests to Shin AI must be authenticated using an API key. Requests without a valid API key will be rejected with a <code>401 Unauthorized</code> error.</p>

      <h2>API Keys</h2>
      <p>You can create, manage, and revoke your API keys from your developer dashboard. Each key is a secret token that should be kept confidential. Do not share your secret API keys in publicly accessible areas such as GitHub, client-side code, and so forth.</p>
      <p>All API requests should be made over HTTPS. Calls made over plain HTTP will be rejected. API requests without authentication will also fail.</p>

      <h2>Using API Keys</h2>
      <p>To authenticate your requests, you need to include your API key in the <code>Authorization</code> header of your HTTP request, using the <code>Bearer</code> authentication scheme.</p>
      <p>Here's an example of what the header should look like:</p>
      <CodeBlock code={authHeader} />

      <h3>Example with cURL</h3>
      <CodeBlock code={curlExample} />

      <h2>Environment Variables</h2>
      <p>For security and convenience, we recommend storing your API key in an environment variable. Our SDKs will automatically detect and use an environment variable named <code>SHIN_API_KEY</code> if it's available.</p>
      <CodeBlock code={envVarExample} />
      <p>By setting this variable, you can avoid hardcoding your key directly in your application code.</p>
    </div>
  );
};

export default Authentication;