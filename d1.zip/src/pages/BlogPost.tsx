import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { useParams, Link } from "react-router-dom";
import { blogPosts } from "@/data/blog";
import NotFound from "./NotFound";
import { ArrowLeft } from "lucide-react";
import { PageMetadata } from "@/components/PageMetadata";

const BlogPost = () => {
  const { slug } = useParams();
  const post = blogPosts.find((p) => p.slug === slug);

  if (!post) {
    return <NotFound />;
  }

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata title={post.title} description={post.description} />
      <Header />
      <main className="flex-grow">
        <section className="py-20 md:py-28">
          <div className="container max-w-screen-md">
            <div className="mb-8">
              <Link to="/blog" className="flex items-center text-primary font-semibold hover:underline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Blog
              </Link>
            </div>
            <article className="prose prose-invert max-w-none">
              <div className="mb-8">
                <p className="text-primary font-semibold">{post.category}</p>
                <h1>{post.title}</h1>
                <p className="text-muted-foreground">{post.date}</p>
              </div>
              <div dangerouslySetInnerHTML={{ __html: post.content }} />
            </article>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default BlogPost;