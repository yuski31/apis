import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Hero } from "@/components/sections/Hero";
import { Features } from "@/components/sections/Features";
import { Stats } from "@/components/sections/Stats";
import { Clients } from "@/components/sections/Clients";
import { Trust } from "@/components/sections/Trust";
import { Cta } from "@/components/sections/Cta";
import { AnimatedSection } from "@/components/AnimatedSection";
import { PageMetadata } from "@/components/PageMetadata";
import { SkipToContent } from "@/components/SkipToContent";

const Index = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata
        title="AI Building Blocks for Developers"
        description="Reliable, scalable AI APIs for text, embeddings, vision, and speech—simple pricing, great docs, and transparent limits."
      />
      <SkipToContent />
      <Header />
      <main id="main-content" className="flex-grow">
        <Hero />
        <AnimatedSection>
          <Clients />
        </AnimatedSection>
        <AnimatedSection>
          <Features />
        </AnimatedSection>
        <AnimatedSection>
          <Trust />
        </AnimatedSection>
        <AnimatedSection>
          <Stats />
        </AnimatedSection>
        <AnimatedSection>
          <Cta />
        </AnimatedSection>
      </main>
      <Footer />
    </div>
  );
};

export default Index;