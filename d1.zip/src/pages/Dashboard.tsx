import { Header } from "@/components/layout/Header"
import { Footer } from "@/components/layout/Footer"
import { PageMetadata } from "@/components/PageMetadata"
import { ApiKeyManager } from "@/components/dashboard/ApiKeyManager"
import { UsageChart } from "@/components/dashboard/UsageChart"
import { QuickLinks } from "@/components/dashboard/QuickLinks"

const Dashboard = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata
        title="Developer Dashboard"
        description="Manage your API keys and monitor your usage."
      />
      <Header />
      <main className="flex-grow py-8">
        <div className="container max-w-screen-2xl">
          <h1 className="text-3xl font-bold mb-8">Dashboard</h1>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <UsageChart />
              <ApiKeyManager />
            </div>
            <div className="lg:col-span-1">
              <QuickLinks />
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

export default Dashboard