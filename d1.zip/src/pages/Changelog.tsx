import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { PageMetadata } from "@/components/PageMetadata";

const Changelog = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata
        title="Changelog"
        description="Latest updates, improvements, and bug fixes for Shin."
      />
      <Header />
      <main className="flex-grow">
        <section className="py-20 md:py-28">
          <div className="container max-w-screen-lg">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold">Changelog</h1>
              <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
                Latest updates, improvements, and bug fixes for Shin.
              </p>
            </div>
            <div>
              <h2 className="text-2xl font-bold">July 19, 2024</h2>
              <ul className="list-disc list-inside mt-4 space-y-2">
                <li className="text-muted-foreground"><span className="font-semibold text-foreground">[Added]</span> Initial version of the Shin website.</li>
              </ul>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Changelog;