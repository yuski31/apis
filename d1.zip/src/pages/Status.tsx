import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2, AlertTriangle, ServerOff } from "lucide-react";
import { PageMetadata } from "@/components/PageMetadata";

const services = [
  { name: "API Gateway", status: "Operational", icon: <CheckCircle2 className="text-green-500" /> },
  { name: "NLP API", status: "Operational", icon: <CheckCircle2 className="text-green-500" /> },
  { name: "Computer Vision API", status: "Operational", icon: <CheckCircle2 className="text-green-500" /> },
  { name: "Predictive Analytics API", status: "Degraded Performance", icon: <AlertTriangle className="text-yellow-500" /> },
  { name: "Website & Dashboard", status: "Operational", icon: <CheckCircle2 className="text-green-500" /> },
  { name: "Authentication Service", status: "Major Outage", icon: <ServerOff className="text-red-500" /> },
];

const Status = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata
        title="System Status"
        description="Current status of all Shin AI services."
      />
      <Header />
      <main className="flex-grow">
        <section className="py-20 md:py-28">
          <div className="container max-w-screen-lg">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold">System Status</h1>
              <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
                Current status of all Shin AI services.
              </p>
            </div>
            <Card className="bg-card/50">
              <CardHeader>
                <CardTitle>Current Service Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {services.map((service) => (
                    <div key={service.name} className="flex justify-between items-center p-4 bg-card rounded-lg">
                      <span className="font-medium">{service.name}</span>
                      <div className="flex items-center gap-2">
                        {service.icon}
                        <span>{service.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Status;