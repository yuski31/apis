import { useState } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { FuturisticCard } from "@/components/FuturisticCard";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Check, Minus } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import AnimatedPrice from "@/components/AnimatedPrice";
import { PageMetadata } from "@/components/PageMetadata";

const pricingTiers = [
  {
    name: "Free",
    price: { monthly: 0, yearly: 0 },
    period: "/month",
    description: "For individuals and hobby projects.",
    features: ["5,000 API Calls/month", "Access to all basic APIs", "Community Support"],
    cta: "Start for Free",
  },
  {
    name: "Build",
    price: { monthly: 39, yearly: 399 },
    period: "/month",
    description: "For startups and small businesses.",
    features: ["100,000 API Calls/month", "Higher Rate Limits", "Email Support", "Usage Analytics"],
    cta: "Get Started",
    popular: true,
  },
  {
    name: "Scale",
    price: { monthly: 299, yearly: 2999 },
    period: "/month",
    description: "For established businesses and high-traffic applications.",
    features: ["1,000,000 API Calls/month", "Access to premium APIs", "Priority Email & Chat Support", "Dedicated Rate Limits"],
    cta: "Choose Plan",
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    description: "For large-scale deployments with custom needs.",
    features: ["Unlimited API Calls", "Custom AI Model Training", "Dedicated Support & SLA", "Advanced Security Features"],
    cta: "Contact Sales",
  },
];

const faqs = [
    {
        question: "Can I change my plan later?",
        answer: "Yes, you can upgrade or downgrade your plan at any time from your account dashboard. Changes will be prorated for the current billing cycle."
    },
    {
        question: "What happens if I exceed my API call limit?",
        answer: "On the Build and Scale plans, you can opt-in to pay-as-you-go for additional calls beyond your plan's limit. On the Free plan, you will need to upgrade to continue using the service."
    },
    {
        question: "Do you offer discounts for non-profits or educational institutions?",
        answer: "Yes, we offer special discounts for qualifying non-profit organizations and educational institutions. Please contact our sales team for more information."
    }
];

const comparisonFeatures = [
    { feature: "API Calls", free: "5,000/mo", build: "100,000/mo", scale: "1,000,000/mo", enterprise: "Unlimited" },
    { feature: "Basic APIs", free: true, build: true, scale: true, enterprise: true },
    { feature: "Standard APIs", free: false, build: true, scale: true, enterprise: true },
    { feature: "Premium APIs", free: false, build: false, scale: true, enterprise: true },
    { feature: "Usage Analytics", free: false, build: true, scale: true, enterprise: true },
    { feature: "Email Support", free: false, build: true, scale: true, enterprise: true },
    { feature: "Priority Support", free: false, build: false, scale: true, enterprise: true },
    { feature: "Dedicated Support & SLA", free: false, build: false, scale: false, enterprise: true },
    { feature: "Custom Model Training", free: false, build: false, scale: false, enterprise: true },
];

const Pricing = () => {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata
        title="Pricing"
        description="Find the perfect plan for your needs. Start for free and scale as you grow. No hidden fees, cancel anytime."
      />
      <Header />
      <main className="flex-grow">
        <section className="py-20 md:py-28">
          <div className="container max-w-screen-2xl">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold">Find the Perfect Plan for Your Needs</h1>
              <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
                Start for free and scale as you grow. No hidden fees, cancel anytime.
              </p>
            </div>
            <div className="flex justify-center items-center gap-4 mb-12">
                <Label htmlFor="billing-cycle" className={billingCycle === 'monthly' ? 'text-primary' : ''}>Monthly</Label>
                <Switch
                    id="billing-cycle"
                    checked={billingCycle === "yearly"}
                    onCheckedChange={(checked) => setBillingCycle(checked ? "yearly" : "monthly")}
                />
                <Label htmlFor="billing-cycle" className={billingCycle === 'yearly' ? 'text-primary' : ''}>Yearly</Label>
                <Badge variant="outline" className="text-primary border-primary">Save ~15%</Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {pricingTiers.map((tier) => {
                const price = tier.price;
                const isCustom = typeof price === 'string';
                const priceValue = !isCustom ? (billingCycle === 'monthly' ? price.monthly : Math.floor(price.yearly / 12)) : 0;

                return (
                    <FuturisticCard key={tier.name} className={`flex flex-col ${tier.popular ? 'hover:shadow-primary/40' : ''}`} glow={!tier.popular}>
                    <FuturisticCard.Header>
                        <FuturisticCard.Title>{tier.name}</FuturisticCard.Title>
                        <div className="text-4xl font-bold pt-4">
                        {isCustom ? (
                            price
                        ) : (
                            <>
                            $
                            <AnimatedPrice price={priceValue} />
                            </>
                        )}
                        <span className="text-lg font-normal text-muted-foreground">{tier.period}</span>
                        </div>
                        <FuturisticCard.Description className="pt-2">{tier.description}</FuturisticCard.Description>
                    </FuturisticCard.Header>
                    <FuturisticCard.Content className="flex-grow">
                        <ul className="space-y-3">
                        {tier.features.map((feature) => (
                            <li key={feature} className="flex items-center text-sm">
                            <CheckCircle2 className="h-4 w-4 mr-2 text-primary" />
                            <span className="text-muted-foreground">{feature}</span>
                            </li>
                        ))}
                        </ul>
                    </FuturisticCard.Content>
                    <FuturisticCard.Footer>
                        <Button className="w-full" variant={tier.popular ? 'default' : 'outline'}>{tier.cta}</Button>
                    </FuturisticCard.Footer>
                    </FuturisticCard>
                );
              })}
            </div>
          </div>
        </section>

        <section className="py-20 md:py-28">
            <div className="container max-w-screen-lg">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold">Compare Features</h2>
                </div>
                <Card className="bg-card/50">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-[250px]">Features</TableHead>
                                <TableHead>Free</TableHead>
                                <TableHead>Build</TableHead>
                                <TableHead>Scale</TableHead>
                                <TableHead>Enterprise</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {comparisonFeatures.map((item) => (
                                <TableRow key={item.feature}>
                                    <TableCell className="font-medium">{item.feature}</TableCell>
                                    <TableCell>{typeof item.free === 'boolean' ? (item.free ? <Check className="text-primary" /> : <Minus className="text-muted-foreground" />) : item.free}</TableCell>
                                    <TableCell>{typeof item.build === 'boolean' ? (item.build ? <Check className="text-primary" /> : <Minus className="text-muted-foreground" />) : item.build}</TableCell>
                                    <TableCell>{typeof item.scale === 'boolean' ? (item.scale ? <Check className="text-primary" /> : <Minus className="text-muted-foreground" />) : item.scale}</TableCell>
                                    <TableCell>{typeof item.enterprise === 'boolean' ? (item.enterprise ? <Check className="text-primary" /> : <Minus className="text-muted-foreground" />) : item.enterprise}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </Card>
            </div>
        </section>

        <section className="py-20 md:py-28 bg-card/30">
            <div className="container max-w-screen-md">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold">Frequently Asked Questions</h2>
                </div>
                <Accordion type="single" collapsible className="w-full">
                    {faqs.map((faq, i) => (
                        <AccordionItem value={`item-${i+1}`} key={i}>
                            <AccordionTrigger>{faq.question}</AccordionTrigger>
                            <AccordionContent>{faq.answer}</AccordionContent>
                        </AccordionItem>
                    ))}
                </Accordion>
            </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Pricing;