import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { BrainCircuit, Target, Users } from "lucide-react";
import { PageMetadata } from "@/components/PageMetadata";

const About = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <PageMetadata
        title="About Us"
        description="We're on a mission to make artificial intelligence accessible and transformative for every developer and business."
      />
      <Header />
      <main className="flex-grow">
        <section className="py-20 md:py-28">
          <div className="container max-w-screen-lg">
            <div className="text-center mb-16">
              <h1 className="text-4xl md:text-5xl font-bold">About Shin AI</h1>
              <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
                We're on a mission to make artificial intelligence accessible and transformative for every developer and business.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div className="p-6 bg-card/50 rounded-lg">
                <Target className="h-12 w-12 text-primary mx-auto mb-4" />
                <h2 className="text-2xl font-bold mb-2">Our Mission</h2>
                <p className="text-muted-foreground">To empower innovation by providing powerful, reliable, and easy-to-use intelligent APIs.</p>
              </div>
              <div className="p-6 bg-card/50 rounded-lg">
                <BrainCircuit className="h-12 w-12 text-primary mx-auto mb-4" />
                <h2 className="text-2xl font-bold mb-2">Our Vision</h2>
                <p className="text-muted-foreground">To be the foundational AI layer for the next generation of applications and services.</p>
              </div>
              <div className="p-6 bg-card/50 rounded-lg">
                <Users className="h-12 w-12 text-primary mx-auto mb-4" />
                <h2 className="text-2xl font-bold mb-2">Our Team</h2>
                <p className="text-muted-foreground">A passionate group of engineers, researchers, and designers dedicated to pushing the boundaries of AI.</p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default About;