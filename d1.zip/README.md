# Shin - AI Building Blocks for Developers

This is the production-ready marketing and documentation website for Shin, a developer-first AI API platform.

## Features

- **Marketing Pages:** Home, Pricing, About, Contact, Careers, Blog, Changelog.
- **Developer Docs:** Comprehensive guides, API reference, and SDK information.
- **Legal Pages:** Terms of Service & Privacy Policy.
- **Responsive Design:** Fully accessible and usable on all devices.
- **Performance Optimized:** Built to be fast and efficient.
- **SEO-Friendly:** Includes meaningful meta tags, a sitemap, and structured data.

## Tech Stack

- **Framework:** React (with Vite)
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **Routing:** React Router
- **Linting/Formatting:** ESLint + Prettier

## Getting Started

### Prerequisites

- Node.js (v18 or later)
- npm or yarn

### Environment Variables

Create a `.env.local` file in the root of the project and add the following environment variables. These are used for analytics and site metadata.

```
VITE_GA4_ID=G-XXXXXXX
VITE_APP_URL=https://shin.example
```

### Installation and Local Development

1.  **Clone the repository:**
    ```bash
    git clone <repository-url>
    cd <repository-name>
    ```

2.  **Install dependencies:**
    ```bash
    npm install
    ```

3.  **Run the development server:**
    ```bash
    npm run dev
    ```
    The application will be available at `http://localhost:8080`.

## Build and Deployment

-   **Build for production:**
    ```bash
    npm run build
    ```
    This command generates a `dist` directory with the optimized, static assets.

-   **Deployment:**
    We recommend deploying to a platform like Vercel, Netlify, or Cloudflare Pages for the best performance and developer experience. Connect your Git repository and the platform will automatically build and deploy the site upon new commits.

## Customization

-   **Brand Colors & Fonts:**
    -   Colors are defined as CSS variables in `src/globals.css`. You can update the `:root` and `.dark` theme variables there.
    -   Fonts are configured in `tailwind.config.ts`.

-   **Pricing Tiers:**
    -   Pricing plans and features can be updated in the `src/pages/Pricing.tsx` file.

-   **Content:**
    -   Blog posts and changelog entries are managed in `src/data/`.
    -   Documentation content is located within the `src/pages/docs/` directory.